using System.ComponentModel.DataAnnotations;

namespace UserService.Application.DTO
{
    public class CreateUserRequest
    {
        [Required]
        public string Nickname { get; set; } = string.Empty;
        [Required]
        public string Login { get; set; } = string.Empty;
        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;
    }
} 