using System.Collections.Generic;
using System.Threading.Tasks;
using UserService.Application.DTO;

namespace UserService.Application.Services
{
    public interface IUserService
    {
        Task<IEnumerable<UserDto>> GetAllAsync();
        Task<UserDto?> GetByIdAsync(int id);
        Task<UserDto> CreateAsync(CreateUserRequest request);
        Task<bool> UpdateAsync(UpdateUserRequest request);
        Task<bool> DeleteAsync(int id);
    }
} 